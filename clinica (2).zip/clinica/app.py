import json
from flask import Flask, render_template, request, redirect, url_for, Response, abort
import pymysql
import pymysql.cursors
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins=["http://localhost:3000", "http://127.0.0.1:3000"])

DB_CONFIG = dict(
    host="localhost",
    user="root",
    password="",
    database="camelo",
    charset="utf8mb4",
    cursorclass=pymysql.cursors.DictCursor,
)


def get_connection():
    return pymysql.connect(**DB_CONFIG)


TABLAS = {
    "pacientes": "pac_id",
    "medicos": "med_id",
    "tratamientos": "trat_id",
    "citas": "cita_id",
}

COLUMNAS = {
    "pacientes": ["pac_id", "pac_nombres", "pac_apellidos", "pac_fechanacimiento", "pac_sexo"],
    "medicos": ["med_id", "med_nombres", "med_apellidos", "med_especialidad", "med_telefono", "med_email"],
    "tratamientos": ["trat_id", "trat_nombre", "trat_descripcion", "trat_precio", "trat_duracion", "trat_pac_id"],
    "citas": ["cita_id", "cita_pac_id", "cita_med_id", "cita_trat_id", "cita_fecha", "cita_hora", "cita_estado"],
}


def obtener_todos(tabla):
    """SELECT * de una tabla permitida; devuelve [] si falla la consulta."""
    if tabla not in TABLAS:
        return []
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {tabla}")
        filas = cur.fetchall()
        cur.close()
        conn.close()
        return [
            {k: (v if v is None or isinstance(v, (int, str)) else str(v)) for k, v in f.items()}
            for f in filas
        ]
    except Exception as e:
        print(f"Error al consultar {tabla}:", e)
        return []


def _json(data, status=200):
    """Respuesta JSON que convierte fechas, horas y decimales a texto."""
    return Response(
        json.dumps(data, default=str, ensure_ascii=False),
        status=status,
        mimetype="application/json",
    )


# ======================================================================
#  PÁGINAS (formularios con plantillas HTML de Flask)
# ======================================================================

@app.route("/")
def inicio():
    return render_template("index.html")


@app.route('/pacientes', methods=["GET", "POST"])
def pacientes():
    if request.method == "POST":
        pac_id = request.form["pac_id"]
        pac_nombres = request.form["pac_nombres"]
        pac_apellidos = request.form["pac_apellidos"]
        pac_fechanacimiento = request.form["pac_fechanacimiento"]
        pac_sexo = request.form["pac_sexo"]

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO pacientes (pac_id, pac_nombres, pac_apellidos, pac_fechanacimiento, pac_sexo) VALUES (%s, %s, %s, %s, %s)",
                (pac_id, pac_nombres, pac_apellidos, pac_fechanacimiento, pac_sexo)
            )
            conn.commit()
            cur.close()
            conn.close()
            return redirect(url_for('pacientes'))
        except Exception as e:
            print("Error al guardar paciente:", e)
            return f"Ocurrió un error al guardar el paciente: {e}"

    return render_template("paciente.html", registros=obtener_todos("pacientes"))


@app.route('/medicos', methods=["GET", "POST"])
def medicos():
    if request.method == "POST":
        med_id = request.form["med_id"]
        med_nombres = request.form["med_nombres"]
        med_apellidos = request.form["med_apellidos"]
        med_especialidad = request.form["med_especialidad"]
        med_telefono = request.form["med_telefono"]
        med_email = request.form["med_email"]

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO medicos (med_id, med_nombres, med_apellidos, med_especialidad, med_telefono, med_email) VALUES (%s, %s, %s, %s, %s, %s)",
                (med_id, med_nombres, med_apellidos, med_especialidad, med_telefono, med_email)
            )
            conn.commit()
            cur.close()
            conn.close()
            return redirect(url_for('medicos'))
        except Exception as e:
            print("Error al guardar médico:", e)
            return f"Ocurrió un error al guardar el médico: {e}"

    return render_template("medico.html", registros=obtener_todos("medicos"))


@app.route('/tratamientos', methods=["GET", "POST"])
def tratamientos():
    if request.method == "POST":
        trat_id = request.form["trat_id"]
        trat_nombre = request.form["trat_nombre"]
        trat_descripcion = request.form["trat_descripcion"]
        trat_precio = request.form["trat_precio"]
        trat_duracion = request.form["trat_duracion"]
        trat_pac_id = request.form["trat_pac_id"]

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO tratamientos (trat_id, trat_nombre, trat_descripcion, trat_precio, trat_duracion, trat_pac_id) VALUES (%s, %s, %s, %s, %s, %s)",
                (trat_id, trat_nombre, trat_descripcion, trat_precio, trat_duracion, trat_pac_id)
            )
            conn.commit()
            cur.close()
            conn.close()
            return redirect(url_for('tratamientos'))
        except Exception as e:
            print("Error al guardar tratamiento:", e)
            return f"Ocurrió un error al guardar el tratamiento: {e}"

    lista_pacientes = obtener_todos("pacientes")
    nombres_pac = {p["pac_id"]: f'{p["pac_nombres"]} {p["pac_apellidos"]}' for p in lista_pacientes}
    return render_template(
        "tratamiento.html",
        registros=obtener_todos("tratamientos"),
        pacientes=lista_pacientes,
        nombres_pac=nombres_pac,
    )


@app.route('/citas', methods=["GET", "POST"])
def citas():
    if request.method == "POST":
        cita_id = request.form["cita_id"]
        cita_pac_id = request.form["cita_pac_id"]
        cita_med_id = request.form["cita_med_id"]
        cita_trat_id = request.form["cita_trat_id"]
        cita_fecha = request.form["cita_fecha"]
        cita_hora = request.form["cita_hora"]
        cita_estado = request.form["cita_estado"]

        try:
            conn = get_connection()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO citas (cita_id, cita_pac_id, cita_med_id, cita_trat_id, cita_fecha, cita_hora, cita_estado) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (cita_id, cita_pac_id, cita_med_id, cita_trat_id, cita_fecha, cita_hora, cita_estado)
            )
            conn.commit()
            cur.close()
            conn.close()
            return redirect(url_for('citas'))
        except Exception as e:
            print("Error al guardar cita:", e)
            return f"Ocurrió un error al guardar la cita: {e}"

    lista_pacientes = obtener_todos("pacientes")
    lista_medicos = obtener_todos("medicos")
    lista_tratamientos = obtener_todos("tratamientos")
    nombres_pac = {p["pac_id"]: f'{p["pac_nombres"]} {p["pac_apellidos"]}' for p in lista_pacientes}
    nombres_med = {m["med_id"]: f'{m["med_nombres"]} {m["med_apellidos"]}' for m in lista_medicos}
    nombres_trat = {t["trat_id"]: t["trat_nombre"] for t in lista_tratamientos}
    return render_template(
        "citas.html",
        registros=obtener_todos("citas"),
        pacientes=lista_pacientes,
        nombres_pac=nombres_pac,
        medicos=lista_medicos,
        tratamientos=lista_tratamientos,
        nombres_med=nombres_med,
        nombres_trat=nombres_trat,
    )


@app.route('/admin')
def admin():
    try:
        conn = get_connection()
        cur = conn.cursor()

        cur.execute("SELECT COUNT(*) AS total FROM pacientes")
        total_pacientes = cur.fetchone()["total"]

        cur.execute("SELECT COUNT(*) AS total FROM medicos")
        total_medicos = cur.fetchone()["total"]

        cur.execute("SELECT COUNT(*) AS total FROM tratamientos")
        total_tratamientos = cur.fetchone()["total"]

        cur.execute("SELECT COUNT(*) AS total FROM citas WHERE cita_fecha = CURDATE()")
        citas_hoy = cur.fetchone()["total"]

        cur.close()
        conn.close()
    except Exception as e:
        print("Error al cargar el panel administrativo:", e)
        total_pacientes = 0
        total_medicos = 0
        total_tratamientos = 0
        citas_hoy = 0

    return render_template(
        "admn.html",
        total_pacientes=total_pacientes,
        total_medicos=total_medicos,
        total_tratamientos=total_tratamientos,
        citas_hoy=citas_hoy,
    )


# ======================================================================
#  EDITAR Y ELIMINAR (genéricos para las 4 tablas)
# ======================================================================

@app.route("/<tabla>/editar", methods=["POST"])
def editar_registro(tabla):
    """UPDATE <tabla> SET ... WHERE <pk> = id"""
    if tabla not in COLUMNAS:
        abort(404)
    columnas = COLUMNAS[tabla]
    pk = columnas[0]
    resto = columnas[1:]
    try:
        valores = [request.form[c] for c in resto] + [request.form[pk]]
        sets = ", ".join(f"{c} = %s" for c in resto)
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(f"UPDATE {tabla} SET {sets} WHERE {pk} = %s", valores)
        conn.commit()
        cur.close()
        conn.close()
        return redirect(url_for(tabla))
    except Exception as e:
        print(f"Error al editar {tabla}:", e)
        return f"Ocurrió un error al editar el registro: {e}", 500


@app.route("/<tabla>/eliminar/<registro_id>", methods=["POST"])
def eliminar_registro(tabla, registro_id):
    """DELETE FROM <tabla> WHERE <pk> = id"""
    if tabla not in TABLAS:
        abort(404)
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {tabla} WHERE {TABLAS[tabla]} = %s", (registro_id,))
        conn.commit()
        borrados = cur.rowcount
        cur.close()
        conn.close()
        if borrados == 0:
            return f"No existe un registro con ID {registro_id} en {tabla}", 404
        return redirect(url_for(tabla))
    except Exception as e:
        print(f"Error al eliminar de {tabla}:", e)
        return f"Ocurrió un error al eliminar el registro: {e}", 500


# ======================================================================
#  API JSON (las usa React)
# ======================================================================

@app.route("/api/<tabla>", methods=["GET"])
def listar_registros(tabla):
    """GET /api/pacientes, /api/medicos, /api/tratamientos, /api/citas"""
    if tabla not in TABLAS:
        abort(404)
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {tabla}")
        filas = cur.fetchall()
        cur.close()
        conn.close()
        return _json(filas)
    except Exception as e:
        print(f"Error al consultar {tabla}:", e)
        return _json({"error": str(e)}, 500)


@app.route("/api/<tabla>/<registro_id>", methods=["GET"])
def obtener_registro(tabla, registro_id):
    """GET /api/pacientes/1001 -> un solo registro"""
    if tabla not in TABLAS:
        abort(404)
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(f"SELECT * FROM {tabla} WHERE {TABLAS[tabla]} = %s", (registro_id,))
        fila = cur.fetchone()
        cur.close()
        conn.close()
        if fila is None:
            return _json({"error": "Registro no encontrado"}, 404)
        return _json(fila)
    except Exception as e:
        print(f"Error al consultar {tabla}:", e)
        return _json({"error": str(e)}, 500)


@app.route('/api/campeon', methods=['GET'])
def api_get_campeon():
    """Lista de pacientes en JSON."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM pacientes")
        data = cur.fetchall()
        cur.close()
        conn.close()
        return _json(data)
    except Exception as e:
        print("Error en /api/campeon:", e)
        return _json({'error': str(e)}, 500)


@app.route('/api/junior')
def api_junior():
    """Todas las citas."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM citas")
        filas = cur.fetchall()
        cur.close()
        conn.close()
        return _json(filas)
    except Exception as e:
        print("Error en /api/junior:", e)
        return _json({"error": str(e)}, 500)
 
 
@app.route('/api/tratamientos')
def api_tratamientos_lista():
    """Todos los tratamientos."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM tratamientos")
        filas = cur.fetchall()
        cur.close()
        conn.close()
        return _json(filas)
    except Exception as e:
        print("Error en /api/tratamientos:", e)
        return _json({"error": str(e)}, 500)
 
 
@app.route('/api/medicos')
def api_medicos():
    """Todos los médicos."""
    try:
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM medicos")
        filas = cur.fetchall()
        cur.close()
        conn.close()
        return _json(filas)
    except Exception as e:
        print("Error en /api/medicos:", e)
        return _json({"error": str(e)}, 500)
 
 

 

 


if __name__ == "__main__":
    app.run(debug=True)